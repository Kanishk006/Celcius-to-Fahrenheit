a=float(input())
f=a*9/5+32
print(f)